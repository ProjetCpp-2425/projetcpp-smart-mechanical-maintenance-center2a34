#include "transaction.h"
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDate>
#include <QMainWindow>
#include <QObject>
#include <QSharedDataPointer>
#include <QWidget>
#include <QSqlError>
#include <QDebug>
#include <QMessageBox>
#include <QSqlQueryModel>
// Constructor implementations
Transaction::Transaction() : id_transaction(0), montant_de_transaction(0.0) {}

Transaction::Transaction(int id, int montant, QDate date, QString type, QString mode)
    : id_transaction(id), montant_de_transaction(montant), date_de_transaction(date), type_de_transaction(type), mode_de_paiement(mode)
{

}

// Setter methods
void Transaction::setIdTransaction(int id) {
    id_transaction = id;
}

void Transaction::setMontantDeTransaction(double montant) {
    montant_de_transaction = montant;
}

void Transaction::setDateDeTransaction(const QDate& date) {
    date_de_transaction = date;
}

void Transaction::setTypeDeTransaction(const QString& type) {
    type_de_transaction = type;
}

void Transaction::setModeDePaiement(const QString& mode) {
    mode_de_paiement = mode;
}

// Getter methods
int Transaction::getIdTransaction() const {
    return id_transaction;
}

double Transaction::getMontantDeTransaction() const {
    return montant_de_transaction;
}

QDate Transaction::getDateDeTransaction() const {
    return date_de_transaction;
}

QString Transaction::getTypeDeTransaction() const {
    return type_de_transaction;
}

QString Transaction::getModeDePaiement() const {
    return mode_de_paiement;
}
//---------------------------------------------------------------------Ajouter
bool Transaction::ajouter()
{
    QSqlQuery query;
    query.prepare("INSERT INTO TRANSACTIONS (ID_TRANSACTION, MONTANT_DE_TRANSACTION, DATE_DE_TRANSACTION, TYPE_DE_TRANSACTION, MODE_DE_PAIEMENT) VALUES (:ID_TRANSACTION, :MONTANT_DE_TRANSACTION, :DATE_DE_TRANSACTION, :TYPE_DE_TRANSACTION, :MODE_DE_PAIEMENT)");

    query.bindValue(":ID_TRANSACTION", id_transaction);
    query.bindValue(":MONTANT_DE_TRANSACTION", montant_de_transaction);
    query.bindValue(":DATE_DE_TRANSACTION", date_de_transaction);
    query.bindValue(":TYPE_DE_TRANSACTION", type_de_transaction);
    query.bindValue(":MODE_DE_PAIEMENT", mode_de_paiement);

    if (!query.exec()) {
        qDebug() << "SQL error:" << query.lastError().text();  // Include <QSqlError> for lastError()
        return false;
    }

    return true;
}
//----------------------------------------------------------------------------------------------------delete
bool Transaction::supprimer(int id) {
    QSqlQuery query;
    QString res = QString::number(id);

    query.prepare("DELETE FROM TRANSACTIONS WHERE ID_TRANSACTION = :ID_TRANSACTION");
    query.bindValue(":ID_TRANSACTION", res);

    /*if (!query.exec()) {
        qDebug() << "Error deleting record:" << query.lastError().text();  // Log the error message
        return false;
    }
    else
    {        QMessageBox::information(nullptr, QObject::tr("Success"),
                                      QObject::tr("Record deleted successfully."));


    return true;
    }*/
    query.exec();
}
//-------------------------------------------------------------------------------------------------afficher
QSqlQueryModel * Transaction::afficher()
{
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("select * from TRANSACTIONS INFO");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_TRANSACTION"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("MONTANT"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("DATE_DE_TRANSACTION"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("TYPE_DE_TRANSACTION"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("MODE_DE_PAIEMENT"));
    return model;
}
//-----------------------------------------------------------------------------------------------------modifier
bool Transaction::fetchData(QString id) {
    QSqlQuery query;
    query.prepare("SELECT * FROM TRANSACTIONS WHERE ID_TRANSACTION = :ID_TRANSACTION");
    query.bindValue(":ID_TRANSACTION", id);

    if (!query.exec()) {
        qDebug() << "Error fetching record:" << query.lastError().text();
        return false;
    }

    if (query.next()) {  // Check if a record is found
        // Assuming your class has member variables for each column
        id_transaction = query.value("ID_TRANSACTION").toInt();
        montant_de_transaction = query.value("MONTANT_DE_TRANSACTION").toInt();
        date_de_transaction = query.value("DATE_DE_TRANSACTION").toDate();
        type_de_transaction = query.value("TYPE_DE_TRANSACTION").toString();
        mode_de_paiement = query.value("MODE_DE_PAIEMENT").toString();



        return true;  // Record found
    } else {
        return false;  // No record found
    }
}

bool Transaction::update(QString id) {
    QSqlQuery query;

    // Prepare the SQL statement for updating a record
    query.prepare("UPDATE TRANSACTIONS SET MONTANT_DE_TRANSACTION = :MONTANT_DE_TRANSACTION, "
                  "DATE_DE_TRANSACTION = TO_DATE(:DATE_DE_TRANSACTION, 'YYYY-MM-DD'), "
                  "TYPE_DE_TRANSACTION = :TYPE_DE_TRANSACTION, "
                  "MODE_DE_PAIEMENT = :MODE_DE_PAIEMENT "
                  "WHERE ID_TRANSACTION = :ID_TRANSACTION ");

    // Bind values to the placeholders
    query.bindValue(":ID_TRANSACTION", id_transaction);
    query.bindValue(":MONTANT_DE_TRANSACTION", montant_de_transaction);
    query.bindValue(":DATE_DE_TRANSACTION", date_de_transaction.toString("yyyy-MM-dd"));
    query.bindValue(":TYPE_DE_TRANSACTION", type_de_transaction);
    query.bindValue(":MODE_DE_PAIEMENT", mode_de_paiement);

    if (!query.exec()) {
        qDebug() << "Update failed:" << query.lastError().text();
        return false;
    }

    return true; // Return true if the update was successful
}
//-----------------------------------------------Sort(trier)
QSqlQueryModel * Transaction::trier(const QString &sortBy) {
    QSqlQueryModel * model = new QSqlQueryModel();
    QString column;

    // Map user-friendly names to actual database columns
    if (sortBy == "ID") column = "ID_TRANSACTION";
    else if (sortBy == "Montant") column = "MONTANT_DE_TRANSACTION";
    else if (sortBy == "Date") column = "DATE_DE_TRANSACTION";
    else if (sortBy == "Type") column = "TYPE_DE_TRANSACTION";
    else if (sortBy == "Mode de Paiement") column = "MODE_DE_PAIEMENT";
    else column = "ID_TRANSACTION"; // Default case if nothing matches

    QString queryStr = "SELECT * FROM TRANSACTIONS ORDER BY " + column;
    model->setQuery(queryStr);

    // Debug output to check the number of rows fetched
    qDebug() << "Number of rows in model after sorting by" << sortBy << ":" << model->rowCount();

    if (model->lastError().isValid()) {
        qDebug() << "SQL Error:" << model->lastError().text();
        return nullptr;
    }

    return model;
}
//---------------------------------------------------rechercher
/*QSqlQueryModel * Transaction::chercher(const QString &id) {
    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery query;
    query.prepare("SELECT * FROM TRANSACTIONS WHERE ID_TRANSACTION = :id");
    query.bindValue(":id", id);
    query.exec();
    model->setQuery(query);

    if (model->lastError().isValid()) {
        qDebug() << "SQL Error:" << model->lastError().text();
        return nullptr;
    }

    return model;
}*/
QSqlQueryModel *Transaction::chercher(const QString &searchText) {
    QSqlQueryModel *model = new QSqlQueryModel();
    QSqlQuery query;

    // Construct the SQL query with LIKE conditions for all relevant attributes
    QString sqlQuery = R"(
        SELECT *
        FROM TRANSACTIONS
        WHERE ID_TRANSACTION LIKE :search
           OR CAST(MONTANT_DE_TRANSACTION AS TEXT) LIKE :search
           OR DATE_DE_TRANSACTION LIKE :search
           OR TYPE_DE_TRANSACTION LIKE :search
           OR MODE_DE_PAIEMENT LIKE :search
    )";

    query.prepare(sqlQuery);
    query.bindValue(":search", "%" + searchText + "%");

    if (!query.exec()) {
        qDebug() << "Search query failed:" << query.lastError().text();
    }

    model->setQuery(query);

    // Debug information
    if (model->lastError().isValid()) {
        qDebug() << "SQL Error in chercher function:" << model->lastError().text();
    } else {
        qDebug() << "Search results row count:" << model->rowCount();
    }

    return model;
}

//----------------------------------------------------Stats
QSqlQueryModel * Transaction::getTransactionStatsByYear() {
    QSqlQueryModel * model = new QSqlQueryModel();
    QSqlQuery query;
    query.prepare("SELECT EXTRACT(YEAR FROM DATE_DE_TRANSACTION) AS Year, SUM(MONTANT_DE_TRANSACTION) AS Total "
                  "FROM TRANSACTIONS "
                  "GROUP BY EXTRACT(YEAR FROM DATE_DE_TRANSACTION) "
                  "ORDER BY Year");
    query.exec();
    model->setQuery(query);

    // Check for SQL errors
    if (model->lastError().isValid()) {
        qDebug() << "SQL Error in stats query:" << model->lastError().text();
    }

    return model;
}


