#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "transaction.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QtCharts>
#include <QSqlRecord>
#include <QPrinter>
#include <QFileDialog>
#include <QTableView>
#include <QChartView>
#include <QPrinter>
#include <QFileDialog>
#include <QChartView>
#include <QPageSize>
#include <QPageLayout>
#include <QPainter>
#include <QPageSize>
#include <QPrinter>
#include <QPainter>
#include <QFileDialog>
#include <QAbstractItemModel>
#include <QPageSize>
#include <QTextDocument>
#include <QUrl>
#include <QDesktopServices>
#include <QSqlError>

//---------------------------------------------------------------last

//------------------------------------------------------------------


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow),chartView(new QChartView(this))
{
    ui->setupUi(this);
    ui->tableView->setModel(Etmp.afficher());
    connect(ui->add, &QPushButton::clicked, this, &::MainWindow::on_add_clicked);
    connect(ui->delete_2, &QPushButton::clicked, this, &::MainWindow::on_delete_2_clicked);
    connect(ui->updateButton, &QPushButton::clicked, this, &::MainWindow::on_updateButton_clicked);
    connect(ui->update2Button, &QPushButton::clicked, this, &::MainWindow::on_update2Button_clicked);
    connect(ui->comboBox_2, SIGNAL(currentIndexChanged(int)), this, SLOT(on_sortComboBox_changed()));
    connect(ui->lineEdit_4, &QLineEdit::textChanged, this, &MainWindow::on_lineEdit_4_textChanged);
    connect(ui->Stats, &QPushButton::clicked, this, &MainWindow::showTransactionStats);
//---------------------------------------------------------------------------------------------------------------------------------
    connect(ui->ouverture, &QPushButton::clicked, this, &MainWindow::on_ouverture_clicked);

        if (myArduino.connect_arduino() != 0) {
            qDebug() << "Failed to connect to Arduino.";
        } else {
            qDebug() << "Arduino connected successfully.";
        }
//---------------------------------------------------------------------------------------------------------------------------------
    connect(ui->exportPdfButton, &QPushButton::clicked, this, [this]() {
        exportToPDF(ui->tableView);
    });
    connect(ui->SendMail, &QPushButton::clicked, this, &MainWindow::on_SendMail_clicked);
    //---------------------------------------------------------------------------------------------------------------------------
    QPushButton *convertButton = findChild<QPushButton*>("convert");
        if (convertButton) {
            connect(convertButton, &QPushButton::clicked, this, &MainWindow::on_convertButton_clicked);
        } else {
            qDebug() << "Error: 'convert' button not found!";
        }
    //---------------------------------------------------------------------------------------------------------------------------

}

MainWindow::~MainWindow()
{
    delete ui;
}
//-------------------------------------------------ajouter
void MainWindow::on_add_clicked()
{
    //proxyModel->sort(6, Qt::DescendingOrder);


        QString idstr = ui->lineEdit_1->text().trimmed();
        QString montantstr = ui->lineEdit_2->text().trimmed();
        QDate date = ui->dateEdit->date();
        QString type = ui->comboBox_1->currentText();
        QString mode = ui->comboBox->currentText();
        int id = idstr.toInt();
        int montant = montantstr.toInt();


        //Controle de saisie

    Transaction T(id, montant, date, type, mode);
    bool test = T.ajouter();
    if (test) {
        ui->tableView->setModel(Etmp.afficher());
        QMessageBox::information(this, "Success", "Transaction added successfully.");
    } else {
        QMessageBox::critical(this, "Failed", "Error");
    }
}
/*void MainWindow::on_add_clicked()
{
    // Retrieve input from the UI
    QString idstr = ui->lineEdit_1->text().trimmed();
    QString montantstr = ui->lineEdit_2->text().trimmed();
    QDate date = ui->dateEdit->date();
    QString type = ui->comboBox_1->currentText();
    QString mode = ui->comboBox->currentText();

    int id = idstr.toInt();
    int montant = montantstr.toInt();

    // Check if the ID already exists in the database
    QSqlQuery query;
    query.prepare("SELECT COUNT(*) FROM TRANSACTIONS WHERE ID_TRANSACTION = :id");
    query.bindValue(":id", id);
    if (query.exec() && query.next()) {
        int count = query.value(0).toInt();
        if (count > 0) {
            QMessageBox::critical(this, "Error", "Transaction ID already exists. Please use a different ID.");
            return;
        }
    } else {
        QMessageBox::critical(this, "Error", "Failed to check transaction ID. Please try again.");
        return;
    }

    // Proceed with adding the transaction
    Transaction T(id, montant, date, type, mode);
    bool test = T.ajouter();
    if (test) {
        QMessageBox::information(this, "Success", "Transaction added successfully.");
        // Optionally update the view or clear inputs
        // ui->tableView_2->setModel(Etmp.afficher());
    } else {
        QMessageBox::critical(this, "Failed", "Error adding transaction.");
    }
}
*/

//----------------------------------------------------supprimer
void MainWindow::on_delete_2_clicked()
{
   /* QModelIndexList selectedIndexes = ui->tableView->selectionModel()->selectedIndexes();
    if (selectedIndexes.isEmpty()) {
        QMessageBox::warning(this, QObject::tr("Selection Error"), QObject::tr("Please select a cell to delete."));
        return;
    }
    QModelIndex index = selectedIndexes.first();
    if (index.column() != 0) {
        QMessageBox::warning(this, QObject::tr("Selection Error"), QObject::tr("Please select a Prescription Number cell to delete."));
        return;
    }*/
    //int row = index.row();
    QString idstr = ui->lineEdit_3->text().trimmed();
    int id = idstr.toInt();
    //int id = ui->lineEdit_1->model()->index(row, 0).data().toInt();
    bool test = Etmp.supprimer(id);
    if (test) {
        ui->tableView->setModel(Etmp.afficher());
        QMessageBox::information(nullptr, QObject::tr("Success"),
                                 QObject::tr("Record deleted successfully."));
    } else {
        // Display an error message if deletion fails
        QMessageBox::critical(nullptr, QObject::tr("Error"),
                              QObject::tr("Failed to delete the record. Please check your data"));
    }
}
//----------------------------------------------------------------modifier
void MainWindow::on_updateButton_clicked() {
    QString id = ui->enter->text().trimmed(); // Get the material ID to retrieve

    if (id.isEmpty()) {
        QMessageBox::warning(this, "Selection Error", "Please enter a valid Material ID to retrieve.");
        return;
    }

    Transaction M;

    // Fetch data for the given Material ID
    if (M.fetchData(id)) {
        // Fill the form fields with the retrieved data
        ui->lineEdit_1->setText(QString::number(M.getIdTransaction()));
        ui->lineEdit_2->setText(QString::number(M.getMontantDeTransaction()));
        ui->dateEdit->setDate(M.getDateDeTransaction());
        ui->comboBox_1->setCurrentText(M.getTypeDeTransaction());
        ui->comboBox->setCurrentText(M.getModeDePaiement());
    } else
    {
        QMessageBox::warning(this, "Retrieve Error", "No material found with the given ID.");
    }
}


void MainWindow::on_update2Button_clicked() {
    QString id1 = ui->update2Button->text().trimmed(); // Material ID to update

    if (id1.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Please enter a Material ID to update.");
        return;
    }

    // Retrieve updated values from the form
    int id=ui->lineEdit_1->text().toInt();
    int montant_de_transaction = ui->lineEdit_2->text().toInt();
    QDate date_de_transaction = ui->dateEdit->date();
    QString type_de_transaction = ui->comboBox_1->currentText();
    QString mode_de_paiement = ui->comboBox->currentText();



    // Create a Material object with updated values
    Transaction M(id, montant_de_transaction, date_de_transaction, type_de_transaction, mode_de_paiement);
    //Transaction(int id, int montant, QDate date, QString type, QString mode);
    // Attempt to update the material in the database
    if (M.update(id1)) {
        ui->tableView->setModel(Etmp.afficher()); // Refresh the table view
        QMessageBox::information(this, "Success", "Material updated successfully.");
    } else {
        QMessageBox::critical(this, "Error", "Failed to update the material. Please check your input.");
    }
}
//-------------------------------------------------------------Sort(trier)
void MainWindow::on_sortComboBox_changed() {
    QString sortBy = ui->comboBox_2->currentText();
    qDebug() << "Sorting by:" << sortBy;
    QSqlQueryModel *sortedModel = Etmp.trier(sortBy);
    if (sortedModel) {
        qDebug() << "Model sorted. Row count:" << sortedModel->rowCount();
        ui->tableView->setModel(sortedModel);
        ui->tableView->update(); // Force update of the view

    } else {
        qDebug() << "Failed to retrieve or sort model.";
    }
}
//-----------------------------------------------------------recherche
/*void MainWindow::on_lineEdit_4_textChanged(const QString &id) {
    if (id.trimmed().isEmpty()) {
        // If the input is empty, display all transactions
        ui->tableView->setModel(Etmp.afficher());
    } else {
        // Else, display only the searched transaction
        ui->tableView->setModel(Etmp.chercher(id));
    }
}*/
void MainWindow::on_lineEdit_4_textChanged(const QString &searchText) {
    QSqlQueryModel *model = new QSqlQueryModel();
    QSqlQuery query;

    // Adjust SQL query for Oracle
    QString sqlQuery = R"(
        SELECT *
        FROM TRANSACTIONS
        WHERE TO_CHAR(ID_TRANSACTION) LIKE :search
           OR TO_CHAR(MONTANT_DE_TRANSACTION) LIKE :search
           OR TO_CHAR(DATE_DE_TRANSACTION, 'YYYY-MM-DD') LIKE :search
           OR TYPE_DE_TRANSACTION LIKE :search
           OR MODE_DE_PAIEMENT LIKE :search
    )";

    query.prepare(sqlQuery);

    // Bind the search text with wildcard for partial matching
    query.bindValue(":search", "%" + searchText + "%");

    // Execute the query
    if (query.exec()) {
        model->setQuery(std::move(query)); // Move the query to avoid deprecated warnings
        ui->tableView->setModel(model);   // Set the model to the table view
        qDebug() << "Search query executed successfully.";
    } else {
        qDebug() << "Search query failed:" << query.lastError().text();
    }
}



//------------------------------------------------------------Stats


/*void MainWindow::showTransactionStats() {
    QSqlQueryModel *model = Etmp.getTransactionStatsByYear();
    if (model->rowCount() == 0) {
        QMessageBox::information(this, "No Data", "No transaction data available to display.");
        return;
    }

    QBarSet *barSet = new QBarSet("Total Amount");
    QStringList categories;

    for (int i = 0; i < model->rowCount(); ++i) {
        QSqlRecord record = model->record(i);
        categories << record.value("Year").toString();
        *barSet << record.value("Total").toDouble();
    }

    QBarSeries *series = new QBarSeries();
    series->append(barSet);

    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Total Amount of Transactions by Year");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    QValueAxis *axisY = new QValueAxis();
    axisY->setTitleText("Total Amount (Dinars)");
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    chart->setBackgroundBrush(QBrush(Qt::white));
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);

    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    QWidget *placeholderWidget = ui->Stat_W; // Make sure this is correctly named in your UI file
    chartView->setParent(placeholderWidget);
    chartView->resize(placeholderWidget->size());
    chartView->show();
}*/
//--------------
//--------------
void MainWindow::showTransactionStats() {
    QSqlQueryModel *model = Etmp.getTransactionStatsByYear();
    if (model->rowCount() == 0) {
        QMessageBox::information(this, "No Data", "No transaction data available to display.");
        return;
    }

    // Bar Chart - Total Transactions by Year
    QBarSet *barSet = new QBarSet("Total Amount");
    QStringList categories;

    for (int i = 0; i < model->rowCount(); ++i) {
        QSqlRecord record = model->record(i);
        categories << record.value("Year").toString();
        *barSet << record.value("Total").toDouble();
    }

    QBarSeries *barSeries = new QBarSeries();
    barSeries->append(barSet);

    QChart *barChart = new QChart();
    barChart->addSeries(barSeries);
    barChart->setTitle("Total Amount of Transactions by Year");
    barChart->setAnimationOptions(QChart::SeriesAnimations);

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    barChart->addAxis(axisX, Qt::AlignBottom);
    barSeries->attachAxis(axisX);

    QValueAxis *axisY = new QValueAxis();
    axisY->setTitleText("Total Amount");
    barChart->addAxis(axisY, Qt::AlignLeft);
    barSeries->attachAxis(axisY);

    barChart->setBackgroundBrush(QBrush(Qt::white));
    barChart->legend()->setVisible(true);
    barChart->legend()->setAlignment(Qt::AlignBottom);

    QChartView *barChartView = new QChartView(barChart);
    barChartView->setRenderHint(QPainter::Antialiasing);

    // Pie Chart - Transaction Type Distribution
    QSqlQuery typeQuery;
    typeQuery.prepare("SELECT TYPE_DE_TRANSACTION, COUNT(*) AS Count "
                      "FROM TRANSACTIONS "
                      "GROUP BY TYPE_DE_TRANSACTION");
    if (!typeQuery.exec()) {
        QMessageBox::critical(this, "Error", "Failed to fetch transaction type data.");
        return;
    }

    QPieSeries *pieSeries = new QPieSeries();
    while (typeQuery.next()) {
        QString type = typeQuery.value("TYPE_DE_TRANSACTION").toString();
        int count = typeQuery.value("Count").toInt();
        pieSeries->append(type, count);
    }

    QChart *pieChart = new QChart();
    pieChart->addSeries(pieSeries);
    pieChart->setTitle("Transaction Type Distribution");
    pieChart->setAnimationOptions(QChart::SeriesAnimations);
    pieChart->legend()->setAlignment(Qt::AlignRight);

    QChartView *pieChartView = new QChartView(pieChart);
    pieChartView->setRenderHint(QPainter::Antialiasing);

    // Display Both Charts in a New Window
    QWidget *statsWidget = new QWidget;
    QVBoxLayout *layout = new QVBoxLayout(statsWidget);

    layout->addWidget(barChartView); // Add Bar Chart
    layout->addWidget(pieChartView); // Add Pie Chart

    statsWidget->setLayout(layout);
    statsWidget->setWindowTitle("Transaction Statistics");
    statsWidget->resize(800, 600); // Set an appropriate size
    statsWidget->show();
}

/*void MainWindow::showTransactionStats() {
    QSqlQueryModel *model = Etmp.getTransactionStatsByYear();
    if (model->rowCount() == 0) {
        QMessageBox::information(this, "No Data", "No transaction data available to display.");
        return;
    }

    QBarSet *barSet = new QBarSet("Total Amount");
    QStringList categories;

    for (int i = 0; i < model->rowCount(); ++i) {
        QSqlRecord record = model->record(i);
        categories << record.value("Year").toString();
        *barSet << record.value("Total").toDouble();
    }

    QBarSeries *series = new QBarSeries();
    series->append(barSet);

    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Total Amount of Transactions by Year");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    QValueAxis *axisY = new QValueAxis();
    axisY->setTitleText("Total Amount (Dinars)");
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    // Create the layout and close button
    QVBoxLayout *layout = new QVBoxLayout();
    QPushButton *closeButton = new QPushButton("Close");
    connect(closeButton, &QPushButton::clicked, chartView, &QWidget::close);

    layout->addWidget(chartView);
    layout->addWidget(closeButton);

    QWidget *chartContainer = new QWidget();
    chartContainer->setLayout(layout);
    chartContainer->resize(400, 300);  // Adjust size as necessary
    chartContainer->show();
}*/
/*void MainWindow::showTransactionStats() {
    // Ensure the model and chart data is ready
    QSqlQueryModel *model = Etmp.getTransactionStatsByYear();
    if (model->rowCount() == 0) {
        QMessageBox::information(this, "No Data", "No transaction data available to display.");
        return;
    }

    // Prepare the chart, resetting any existing chart first
    chartView->setChart(new QChart());  // Reset chart with a fresh instance
    QChart *chart = chartView->chart();

    // Create the dataset
    QBarSet *barSet = new QBarSet("Total Amount");
    QStringList categories;

    // Populate data from the model
    for (int i = 0; i < model->rowCount(); ++i) {
        QSqlRecord record = model->record(i);
        categories << record.value("Year").toString();
        *barSet << record.value("Total").toDouble();
    }

    // Setup series and append the dataset
    QBarSeries *series = new QBarSeries();
    series->append(barSet);

    // Configure the chart
    chart->addSeries(series);
    chart->setTitle("Total Amount of Transactions by Year");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    // Configure axis for the chart
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    QValueAxis *axisY = new QValueAxis();
    axisY->setTitleText("Total Amount (Dinars)");
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    // Optionally set the chartView properties if needed
    chartView->setRenderHint(QPainter::Antialiasing);

    // Since chartView is already part of your UI, you might just need to refresh or reposition it
    chartView->repaint();  // Repaint the chartView to update its display
    chartView->show();     // Ensure it's visible (if it was previously hidden)

    // No need to setup layout again since chartView is now a member and should be managed by the main window layout
}
*/

//---------------------------------------------------------------------------
//----------------------------------------------------------EXPORT
//---------------------------------------------------------------------------
/*void MainWindow::exportToPDF(QTableView *tableView, QChartView *chartView) {
    QString filePath = QFileDialog::getSaveFileName(this, tr("Save PDF"), "", tr("PDF files (*.pdf)"));
    if (filePath.isEmpty())
        return;

    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setPageSize(QPageSize(QPageSize::A4));  // Set paper size
    printer.setPageOrientation(QPageLayout::Landscape);  // Set orientation
    printer.setOutputFileName(filePath);

    QPainter painter;
    if (!painter.begin(&printer)) {  // Start print job
        QMessageBox::warning(this, tr("Printing Error"), tr("Failed to open file for writing."));
        return;
    }

    // Render the table
    tableView->render(&painter);

    // Start a new page for the chart
    printer.newPage();

    // Get the full rectangle from page layout for the printer
    QRect chartArea = printer.pageLayout().fullRect(QPageLayout::Point).toRect();  // Convert QRectF to QRect

    // Render the chart
    chartView->scene()->render(&painter, chartArea, QRectF(0, 0, chartArea.width(), chartArea.height()), Qt::KeepAspectRatio);

    painter.end();  // End print job
}*/


/*void MainWindow::exportToPDF(QTableView *tableView, QChartView *chartView) {
    QString filePath = QFileDialog::getSaveFileName(this, tr("Save PDF"), "", tr("PDF files (*.pdf)"));
    if (filePath.isEmpty()) return;

    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setPageSize(QPageSize(QPageSize::A4));
    printer.setPageOrientation(QPageLayout::Landscape);
    printer.setOutputFileName(filePath);

    // Adjust the page layout with minimal margins
    QPageLayout layout = printer.pageLayout();
    layout.setMargins(QMarginsF(5.0, 5.0, 5.0, 5.0)); // Set margins
    printer.setPageLayout(layout);

    QPainter painter;
    if (!painter.begin(&printer)) {
        QMessageBox::warning(this, tr("Printing Error"), tr("Failed to open file for writing."));
        return;
    }

    // Scale to fit the table width to the page width
    qreal scaleFactor = printer.pageLayout().paintRect().width() / tableView->width();
    painter.scale(scaleFactor, scaleFactor);

    tableView->render(&painter);

    // New page for the chart
    printer.newPage();
    painter.resetTransform();

    QRectF chartArea = printer.pageLayout().paintRect();
    chartView->scene()->render(&painter, chartArea, QRectF(0, 0, chartView->width(), chartView->height()), Qt::KeepAspectRatio);

    painter.end();
}*/
void MainWindow::exportToPDF(QTableView *tableView) {
    QString fileName = QFileDialog::getSaveFileName(this, "Export Table to PDF", "", "*.pdf");
    if (fileName.isEmpty()) {
        return;
    }

    if (!fileName.endsWith(".pdf", Qt::CaseInsensitive)) {
        fileName += ".pdf";
    }

    QPdfWriter pdfWriter(fileName);
    pdfWriter.setPageSize(QPageSize(QPageSize::A4));
    pdfWriter.setResolution(300);
    QPainter painter(&pdfWriter);

    // Title of the PDF
    painter.setFont(QFont("Arial", 16, QFont::Bold));
    QRect titleRect(0, 0, pdfWriter.width(), 50);
    painter.drawText(titleRect, Qt::AlignCenter, "Exported Transactions Table");

    QAbstractItemModel *model = tableView->model();
    if (!model) {
        QMessageBox::critical(this, "Error", "Failed to fetch data from tableView.");
        return;
    }

    int x = 50;
    int y = 100;
    int rowHeight = 40;
    int totalWidth = pdfWriter.width() - 100;
    QVector<int> columnWidths(model->columnCount());

    // Adjust column widths proportionally to ensure all columns fit
    int totalDynamicWidth = 0;
    QVector<int> maxWidths(model->columnCount());
    for (int column = 0; column < model->columnCount(); ++column) {
        int headerWidth = painter.fontMetrics().horizontalAdvance(model->headerData(column, Qt::Horizontal, Qt::DisplayRole).toString());
        int maxWidth = headerWidth;
        for (int row = 0; row < model->rowCount(); ++row) {
            int cellWidth = painter.fontMetrics().horizontalAdvance(model->data(model->index(row, column)).toString());
            maxWidth = qMax(maxWidth, cellWidth);
        }
        maxWidths[column] = maxWidth + 20; // Add padding
        totalDynamicWidth += maxWidths[column];
    }

    // Scale down column widths if they exceed totalWidth
    if (totalDynamicWidth > totalWidth) {
        double scaleFactor = static_cast<double>(totalWidth) / totalDynamicWidth;
        for (int column = 0; column < model->columnCount(); ++column) {
            columnWidths[column] = static_cast<int>(maxWidths[column] * scaleFactor);
        }
    } else {
        columnWidths = maxWidths;
    }

    // Draw the table headers
    painter.setFont(QFont("Arial", 12, QFont::Bold));
    painter.setBrush(QBrush(Qt::gray)); // Header background color
    for (int column = 0; column < model->columnCount(); ++column) {
        QString headerText = model->headerData(column, Qt::Horizontal, Qt::DisplayRole).toString();
        painter.drawRect(x, y, columnWidths[column], rowHeight); // Draw cell border and background
        painter.drawText(x + 5, y + 5, columnWidths[column] - 10, rowHeight - 10, Qt::AlignCenter, headerText);
        x += columnWidths[column];
    }

    y += rowHeight; // Move to the next row
    x = 50;

    // Draw the table rows with alternating colors
    painter.setFont(QFont("Arial", 10));
    for (int row = 0; row < model->rowCount(); ++row) {
        painter.setBrush(row % 2 == 0 ? QBrush(Qt::white) : QBrush(Qt::lightGray)); // Alternate row colors
        for (int column = 0; column < model->columnCount(); ++column) {
            QString value = model->data(model->index(row, column)).toString();

            // Draw background and border
            painter.drawRect(x, y, columnWidths[column], rowHeight);

            // Align text based on column content
            Qt::Alignment alignment = Qt::AlignLeft | Qt::AlignVCenter;
            if (column == 0 || column == 1) // Center align for ID and numeric values
                alignment = Qt::AlignCenter;
            if (column == 2) // Center align for date column
                alignment = Qt::AlignCenter;

            // Draw the text
            painter.drawText(x + 5, y + 5, columnWidths[column] - 10, rowHeight - 10, alignment, value);
            x += columnWidths[column];
        }
        y += rowHeight; // Move to the next row
        x = 50;

        // Check if the page is full
        if (y > pdfWriter.height() - 100) {
            pdfWriter.newPage();
            y = 100;
        }
    }

    painter.end();

    QMessageBox::information(this, "Success", "Table exported to PDF successfully!");
}

//--------------------------------------------------------------------------------------------mailling

void MainWindow::on_SendMail_clicked() {
    // Define the email details
    QString recipient = "example@example.com"; // Replace with the recipient's email address
    QString subject = "Hello from Mechvision!"; // The email subject
    QString body = "Dear User,\n\nThis is a test email sent from the Mechvision application.\n\nBest regards,\nThe Mechvision Team"; // The email body

    // Encode the email details into a mailto link
    QString mailto = QString("mailto:%1?subject=%2&body=%3")
                         .arg(recipient)
                         .arg(subject)
                         .arg(body);

    // Open the default email client
    QDesktopServices::openUrl(QUrl(mailto));
}

//---------------------------------------------------------------------------------------------convert

void MainWindow::on_convertButton_clicked() {
    QUrl url("https://www.xe.com/fr/currencyconverter/convert/?Amount=1&From=TND&To=EUR");
    QDesktopServices::openUrl(url);
}

//----------------------------------------------------------------------------------------------rfid
/*void MainWindow::updateEmployeeStatus(const QString& RFID_UID) {
    QSqlQuery query;
    query.prepare("UPDATE EMPLOYÉ SET ETAT_E = 'disponible' WHERE CIN_E = :uid");
    query.bindValue(":uid", RFID_UID);
    if (!query.exec()) {
        qDebug() << "Error updating employee status:" << query.lastError();
    } else {
        qDebug() << "Employee status updated to disponible for UID:" << RFID_UID;
    }
}*/
//-----------------------------------------------------------------------------------------------openbutton
void MainWindow::on_ouverture_clicked() {
    static bool gateOpen = false; // Toggle state to keep track of gate status

    if (gateOpen) {
        myArduino.write_to_arduino("CLOSE\n");  // Command to close the gate
        qDebug() << "Command sent to close the gate.";
    } else {
        myArduino.write_to_arduino("OPEN\n");   // Command to open the gate
        qDebug() << "Command sent to open the gate.";
    }
    gateOpen = !gateOpen; // Toggle the state
}

