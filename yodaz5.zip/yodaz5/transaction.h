#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <QString>
#include <QDate>
#include <QSqlQueryModel>
class Transaction {
private:
    int id_transaction;
    double montant_de_transaction;
    QDate date_de_transaction; // Using QDate for date management
    QString type_de_transaction;
    QString mode_de_paiement;

public:
    Transaction(); // Default constructor
    Transaction(int id, int montant, QDate date, QString type, QString mode); // Updated constructor with QDate

    // Setters
    void setIdTransaction(int id);
    void setMontantDeTransaction(double montant);
    void setDateDeTransaction(const QDate& date);
    void setTypeDeTransaction(const QString& type);
    void setModeDePaiement(const QString& mode);

    // Getters
    int getIdTransaction() const;
    double getMontantDeTransaction() const;
    QDate getDateDeTransaction() const;
    QString getTypeDeTransaction() const;
    QString getModeDePaiement() const;

    bool ajouter();
    bool supprimer(int id);
    QSqlQueryModel * afficher();
    bool fetchData(QString id);
    bool update(QString id);
    QSqlQueryModel * trier(const QString &sortBy);
    QSqlQueryModel * chercher(const QString &id);
    QSqlQueryModel * getTransactionStatsByYear();

};

#endif // TRANSACTION_H
