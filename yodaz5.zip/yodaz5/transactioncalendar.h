#ifndef TRANSACTIONCALENDAR_H
#define TRANSACTIONCALENDAR_H

#include <QCalendarWidget>
#include <QDate>
#include <QPainter>
#include <QSet>

class TransactionCalendar : public QCalendarWidget {
    Q_OBJECT

public:
    explicit TransactionCalendar(QWidget *parent = nullptr);
    void setTransactionDates(const QSet<QDate>& dates);

protected:
    void paintCell(QPainter *painter, const QRect &rect, const QDate &date) const override;

private:
    QSet<QDate> transactionDates;
};

#endif // TRANSACTIONCALENDAR_H
