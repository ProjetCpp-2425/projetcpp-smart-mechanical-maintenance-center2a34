#include "arduino.h"
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QDebug>

Arduino::Arduino()
{
    data="";
    arduino_port_name="";
    arduino_is_available=false;
    serial=new QSerialPort;
}

QString Arduino::getarduino_port_name()
{
    return arduino_port_name;
}

QSerialPort *Arduino::getserial()
{
    return serial;
}
//----------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------
int Arduino::connect_arduino() {
    qDebug() << "Searching for Arduino Uno...";
    bool portFound = false;
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts()) {
        qDebug() << "Checking port:" << info.portName();
        if (info.hasVendorIdentifier() && info.vendorIdentifier() == arduino_uno_vendor_id &&
            info.hasProductIdentifier() && info.productIdentifier() == arduino_uno_producy_id) {
            arduino_port_name = info.portName();
            portFound = true;
            break;
        }
    }

    if (!portFound) {
        qDebug() << "Arduino not found.";
        return -1;
    }

    serial->setPortName(arduino_port_name);
    qDebug() << "Attempting to open port:" << arduino_port_name;
    if (serial->open(QSerialPort::ReadWrite)) {
        configureSerialPort();
        qDebug() << "Port successfully opened.";
        return 0;
    } else {
        qDebug() << "Failed to open port:" << serial->errorString();
        return 1;
    }
}

void Arduino::configureSerialPort() {
    serial->setBaudRate(QSerialPort::Baud9600);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
}

int Arduino::close_arduino() {
    if (serial->isOpen()) {
        serial->close();
        qDebug() << "Port closed successfully.";
        return 0;
    }
    return 1;
}



//----------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------
/*int Arduino::connect_arduino()
{
    qDebug() << "Searching for Arduino Uno...";
    foreach (const QSerialPortInfo &serial_port_info, QSerialPortInfo::availablePorts()) {
        qDebug() << "Checking port:" << serial_port_info.portName();
        if (serial_port_info.hasVendorIdentifier() && serial_port_info.hasProductIdentifier()) {
            qDebug() << "Vendor ID:" << QString::number(serial_port_info.vendorIdentifier(), 16);
            qDebug() << "Product ID:" << QString::number(serial_port_info.productIdentifier(), 16);

            if (serial_port_info.vendorIdentifier() == arduino_uno_vendor_id && serial_port_info.productIdentifier() == arduino_uno_producy_id)
            {
                arduino_is_available = true;
                arduino_port_name = serial_port_info.portName();
                break;
            }
        }
    }

    qDebug() << "Arduino port name is:" << arduino_port_name;

    if (arduino_is_available) {
        serial->setPortName(arduino_port_name);
        qDebug() << "Attempting to open port:" << arduino_port_name;
        if (serial->open(QSerialPort::ReadWrite)) {
            serial->setBaudRate(QSerialPort::Baud9600);
            serial->setDataBits(QSerialPort::Data8);
            serial->setParity(QSerialPort::NoParity);
            serial->setStopBits(QSerialPort::OneStop);
            serial->setFlowControl(QSerialPort::NoFlowControl);
            qDebug() << "Port successfully opened.";
            return 0;
        } else {
            qDebug() << "Failed to open port:" << arduino_port_name << serial->errorString();
            return 1;
        }
    } else {
        qDebug() << "Arduino not found.";
        return -1;
    }
}


int Arduino::close_arduino()

{

    if(serial->isOpen()){
        serial->close();
        return 0;
    }
    return 1;


}*/
//----------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------
QByteArray Arduino::read_from_arduino() {
    if (serial->waitForReadyRead(2000)) { // Wait up to 2 seconds for data
        QByteArray incomingData = serial->readAll();
        qDebug() << "Raw data from Arduino:" << incomingData;

        data.append(incomingData);

        if (data.contains("\n")) {
            QByteArray message = data.left(data.indexOf("\n")).trimmed();
            data.remove(0, data.indexOf("\n") + 1);
            return message;
        }
    } else {
        qDebug() << "No data received within timeout.";
    }
    return "";
}


void Arduino::write_to_arduino( QByteArray d)

{
    if(serial->isWritable()){
        serial->write(d);  // envoyer des donnés vers Arduino
    }else{
        qDebug() << "Couldn't write to serial!";
    }
}
