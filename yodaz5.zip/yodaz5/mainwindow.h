#ifndef MAINWINDOW_H
#define MAINWINDOW_H
//---------------------------------------------------------------------------------

//---------------------------------------------------------------------------------
#include <QMainWindow>
#include <QTableView>
#include <QChartView>
#include "arduino.h"
#include "transaction.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_add_clicked();
    void on_delete_2_clicked();
    void on_updateButton_clicked();
    void on_update2Button_clicked();
    void on_sortComboBox_changed();
    void on_lineEdit_4_textChanged(const QString &id);
    void showTransactionStats();
    //void exportToPDF(QTableView *tableView, QChartView *chartView);
    void exportToPDF(QTableView *tableView);
    void on_SendMail_clicked();
    //--------------------------------------------------------------------------------last
    void on_convertButton_clicked();
    /*void updateEmployeeStatus(const QString& RFID_UID);*/
    void on_ouverture_clicked();

private:
    Ui::MainWindow *ui;
    QChartView *chartView;
    Transaction Etmp;
    Arduino myArduino;
    //-----------------------------------------------------------------------------------


    //-----------------------------------------------------------------------------------
};

#endif // MAINWINDOW_H
