#include <QApplication>
#include <QMessageBox>
#include "mainwindow.h"
#include "connexion.h"
#include <QCoreApplication>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include "arduino.h"
#include <QThread>

int main(int argc, char *argv[]) {
    Arduino myArduino;
    if (myArduino.connect_arduino() != 0) {
        qDebug() << "Failed to connect to Arduino. Exiting...";
        return -1;
    }
    qDebug() << "Arduino connected successfully.";

    QApplication a(argc, argv);
    connexion c;
    bool test = c.createconnexion();
    MainWindow w;

    if (test) {
        w.show();
        QMessageBox::information(nullptr, QObject::tr("Database is Open"),
                                 QObject::tr("Connection successful.\n"
                                             "Click OK to continue."),
                                 QMessageBox::Ok);

        // Specify the employee CIN you are tracking
        QString employeeCIN = "100";

        while (true) {
            // Step 3: Read data from Arduino
            QByteArray data = myArduino.read_from_arduino();

            if (data.isEmpty()) {
                // Avoid flooding the logs with empty messages; just continue
                continue;
            }

            // Convert the received data to a QString and trim spaces/newlines
            QString status = QString::fromStdString(data.toStdString()).trimmed();
            qDebug() << "Received data from Arduino:" << status;

            // If the card presented matches the expected input or criteria,
            // we proceed to toggle the status. For example, if "disponible"
            // or some specific trigger word indicates the card is recognized.
            // You could also just proceed on any non-empty data if your scenario requires it.
            if (!status.isEmpty()) {
                // Step 4: Check the current status in the database
                QSqlQuery selectQuery;
                selectQuery.prepare("SELECT ETAT_E FROM EMPLOYE WHERE CIN_E = :cin");
                selectQuery.bindValue(":cin", employeeCIN);

                if (!selectQuery.exec()) {
                    QMessageBox::critical(nullptr, QObject::tr("Database Error"),
                                          QObject::tr("Failed to retrieve current status: %1")
                                              .arg(selectQuery.lastError().text()),
                                          QMessageBox::Ok);
                } else if (selectQuery.next()) {
                    QString currentStatus = selectQuery.value(0).toString().trimmed();
                    QString newStatus;

                    // Toggle the status
                    if (currentStatus == "occupe") {
                        newStatus = "disponible";
                    } else {
                        newStatus = "occupe";
                    }

                    // Update the database with the new status
                    QSqlQuery updateQuery;
                    updateQuery.prepare("UPDATE EMPLOYE SET ETAT_E = :etat WHERE CIN_E = :cin");
                    updateQuery.bindValue(":etat", newStatus);
                    updateQuery.bindValue(":cin", employeeCIN);

                    if (!updateQuery.exec()) {
                        QMessageBox::critical(nullptr, QObject::tr("Database Update Failed"),
                                              QObject::tr("Failed to update database: %1")
                                                  .arg(updateQuery.lastError().text()),
                                              QMessageBox::Ok);
                    } else {
                        QMessageBox::information(nullptr, QObject::tr("Database Update Successful"),
                                                 QObject::tr("Employee status toggled successfully to '%1'.").arg(newStatus),
                                                 QMessageBox::Ok);
                    }
                } else {
                    QMessageBox::critical(nullptr, QObject::tr("Database Error"),
                                          QObject::tr("No employee found with CIN: %1").arg(employeeCIN),
                                          QMessageBox::Ok);
                }
            }

            QThread::sleep(2); // Delay between checks/updates if necessary
        }
    } else {
        QMessageBox::critical(nullptr, QObject::tr("Database is Not Open"),
                              QObject::tr("Connection failed.\n"
                                          "Click OK to exit."),
                              QMessageBox::Ok);
    }

    return a.exec();
}



/*#include <QApplication>
#include <QMessageBox>
#include "mainwindow.h"
#include "connexion.h"
#include <QCoreApplication>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include "arduino.h"
#include <QThread>

int main(int argc, char *argv[]) {
    Arduino myArduino;
    if (myArduino.connect_arduino() != 0) {
        qDebug() << "Failed to connect to Arduino. Exiting...";
        return -1;
    }
    qDebug() << "Arduino connected successfully.";

    QApplication a(argc, argv);
    connexion c;
    bool test = c.createconnexion();
    MainWindow w;

    if (test) {
        w.show();
        QMessageBox::information(nullptr, QObject::tr("Database is Open"),
                                 QObject::tr("Connection successful.\n"
                                             "Click OK to continue."),
                                 QMessageBox::Ok);

        while (true) {
            // Step 3: Read data from Arduino
            QByteArray data = myArduino.read_from_arduino();

            if (data.isEmpty()) {
                // Avoid flooding the logs with empty messages; just continue
                continue;
            }

            // Show a QMessageBox with the value of data
            QString status = QString::fromStdString(data.toStdString()).trimmed(); // Convert QByteArray to QString
            QMessageBox::information(nullptr, QObject::tr("Arduino Data Received"),
                                     QObject::tr("Data: %1").arg(status),
                                     QMessageBox::Ok);

            qDebug() << "Received data from Arduino:" << status;

            // Step 4: Insert data into the database
            QSqlQuery query;
            QString state = (status == "disponible") ? "disponible" : "occupe";

            query.prepare("UPDATE EMPLOYE SET ETAT_E = :etat WHERE CIN_E = :cin"); // Update based on CIN_E
            query.bindValue(":etat", state);
            query.bindValue(":cin", "100"); // Replace with the actual CIN_E or dynamically fetch

            if (!query.exec()) {
                QMessageBox::critical(nullptr, QObject::tr("Database Update Failed"),
                                      QObject::tr("Failed to update database: %1")
                                          .arg(query.lastError().text()),
                                      QMessageBox::Ok);
            } else {
                QMessageBox::information(nullptr, QObject::tr("Database Update Successful"),
                                         QObject::tr("Employee status updated successfully to '%1'.").arg(state),
                                         QMessageBox::Ok);
            }

            QThread::sleep(2); // Add delay between iterations (if necessary)
        }
    } else {
        QMessageBox::critical(nullptr, QObject::tr("Database is Not Open"),
                              QObject::tr("Connection failed.\n"
                                          "Click OK to exit."),
                              QMessageBox::Ok);
    }

    return a.exec();
}*/



//-------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------
/*#include <QApplication>
#include <QMessageBox>
#include "mainwindow.h"
#include "connexion.h"
#include <QCoreApplication>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include "arduino.h"
#include <QThread>

int main(int argc, char *argv[])
{   Arduino myArduino;
    if (myArduino.connect_arduino() != 0) {
        qDebug() << "Failed to connect to Arduino. Exiting...";
        return -1;
    }
    qDebug() << "Arduino connected successfully.";


    QApplication a(argc, argv);
    connexion c;
    bool test=c.createconnexion();
    MainWindow w;
    if(test)
    {w.show();
        QMessageBox::information(nullptr, QObject::tr("database is open"),
                    QObject::tr("connexion successful.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
        while (true) {
                // Step 3: Read data from Arduino
                QByteArray data = myArduino.read_from_arduino();
                if (data.isEmpty()) {
                    qDebug() << "No data received from Arduino.";
                    continue;
                }

                QString status = QString::fromStdString(data.toStdString()).trimmed(); // Convert QByteArray to QString
                qDebug() << "Received data from Arduino:" << status;

                // Step 4: Insert data into the database
                QSqlQuery query;
                QString state = (status == "disponible") ? "disponible" : "absent";

                query.prepare("UPDATE EMPLOYE SET ETAT_E = :etat WHERE CIN_E = :cin"); // Update based on CIN_E
                query.bindValue(":etat", state);
                query.bindValue(":cin", "100"); // Replace with the actual CIN_E or dynamically fetch

                if (!query.exec()) {
                    qDebug() << "Failed to execute query:" << query.lastError().text();
                } else {
                    qDebug() << "Employee status updated successfully.";
                }

                QThread::sleep(2); // Add delay between iterations (if necessary)
            }
}
else

        QMessageBox::critical(nullptr, QObject::tr("database is not open"),
                    QObject::tr("connexion failed.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);



    return a.exec();
}*/
/*
#include <QCoreApplication>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include "Arduino.h"

int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);

    // Step 1: Declare and connect Arduino
    Arduino myArduino;
    if (myArduino.connect_arduino() != 0) {
        qDebug() << "Failed to connect to Arduino. Exiting...";
        return -1;
    }
    qDebug() << "Arduino connected successfully.";

    while (true) {
        // Step 3: Read data from Arduino
        QByteArray data = myArduino.read_from_arduino();
        if (data.isEmpty()) {
            qDebug() << "No data received from Arduino.";
            continue;
        }

        QString status = QString::fromStdString(data.toStdString()).trimmed(); // Convert QByteArray to QString
        qDebug() << "Received data from Arduino:" << status;

        // Step 4: Insert data into the database
        QSqlQuery query;
        QString state = (status == "disponible") ? "disponible" : "absent";

        query.prepare("UPDATE EMPLOYE SET ETAT_E = :etat WHERE CIN_E = :cin"); // Update based on CIN_E
        query.bindValue(":etat", state);
        query.bindValue(":cin", "specific_cin_value"); // Replace with the actual CIN_E or dynamically fetch

        if (!query.exec()) {
            qDebug() << "Failed to execute query:" << query.lastError().text();
        } else {
            qDebug() << "Employee status updated successfully.";
        }

        QThread::sleep(2); // Add delay between iterations (if necessary)
    }
}
*/
