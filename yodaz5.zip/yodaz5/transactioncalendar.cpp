#include "TransactionCalendar.h"

TransactionCalendar::TransactionCalendar(QWidget *parent) : QCalendarWidget(parent) {}

void TransactionCalendar::setTransactionDates(const QSet<QDate>& dates) {
    transactionDates = dates;
    updateCells(); // Refresh the calendar to show transaction markers
}

void TransactionCalendar::paintCell(QPainter *painter, const QRect &rect, const QDate &date) const {
    QCalendarWidget::paintCell(painter, rect, date); // Call base method first

    if (transactionDates.contains(date)) {
        painter->save();
        painter->setPen(Qt::NoPen);
        painter->setBrush(QColor(255, 0, 0, 50)); // Semi-transparent red overlay
        painter->drawRect(rect.adjusted(2, 2, -2, -2));
        painter->restore();
    }
}
